

function freememory(){
	for(var i=0;i<0x100000/0x10;i++){
			new String;
		}
}


var vars = new Array(102);

var runcount = {main:0, f0:0, f1:0, f2:0, f3:0, f4:0, f5:0, f6:0, f7:0, f8:0, f9:0}

function main() {
runcount.main++; if(runcount.main>2) return;
//alert('main');
//beginjs
try { var ret = new Array(vars[71], Infinity, vars[83]); if(ret) vars[50] = ret; } catch(e) { }
try { var ret = RegExp.index; if(ret) vars[16] = ret; } catch(e) { }
try { var ret = new RegExp(Array(65537).join(String.fromCharCode(95, 119, 20)) + Array(65).join(String.fromCharCode(74, 34, 51)), 'ggg'); if(ret) vars[94] = ret; } catch(e) { }
try { var ret = Array.prototype.toLocaleString.call(vars[2]); if(ret) vars[41] = ret; } catch(e) { }
try { vars[86][1000000] = false; } catch(e) { }
try { var ret = vars[91].valueOf; if(ret) vars[49] = ret; } catch(e) { }
try { vars[11] = Array; } catch(e) { }
try { var ret = RuntimeObject(); if(ret) vars[43] = ret; } catch(e) { }
try { vars[96].toExponential = arg4; } catch(e) { }
try { freememory(); } catch(e) { }
try { var ret = Date.prototype.toLocaleTimeString.call(vars[1]); if(ret) vars[62] = ret; } catch(e) { }
try { var ret = vars[62].call(vars[66]); if(ret) vars[29] = ret; } catch(e) { }
try { vars[72].valueOf = true; } catch(e) { }
try { vars[74] = new Array(1000000); } catch(e) { }
try { var ret = RegExp.$8; if(ret) vars[60] = ret; } catch(e) { }
try { var ret = new Array(); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = isFinite(arg5); if(ret) vars[20] = ret; } catch(e) { }
try { var ret = Array.prototype.pop.call(vars[36]); if(ret) vars[61] = ret; } catch(e) { }
try { var ret = RegExp.$5; if(ret) vars[41] = ret; } catch(e) { }
try { vars[40].toPrecision = vars[95]; } catch(e) { }
try { var ret = vars[30].caller; if(ret) vars[51] = ret; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[19], vars[13], vars[55]); if(ret) vars[14] = ret; } catch(e) { }
try { vars[89].foo = false; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[91]); if(ret) vars[29] = ret; } catch(e) { }
try { var ret = Array.prototype.reverse.call(vars[66]); if(ret) vars[66] = ret; } catch(e) { }
try { var ret = vars[7].lastIndex; if(ret) vars[93] = ret; } catch(e) { }
try { var ret = arguments; if(ret) vars[11] = ret; } catch(e) { }
try { var ret = new Error(vars[62]); if(ret) vars[45] = ret; } catch(e) { }
try { vars[94] = new Array(-1); } catch(e) { }
try { RegExp.prototype.exec.call(vars[47], Array(17).join(String.fromCharCode(66)) + Array(257).join(String.fromCharCode(102, 36, 49))); } catch(e) { }
try { var ret = RegExp.lastIndex; if(ret) vars[53] = ret; } catch(e) { }
try { var ret = String.FromCharCode(vars[84], vars[60], vars[30]); if(ret) vars[22] = ret; } catch(e) { }
try { vars[64].toString = 2147483648; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[84], vars[15], vars[14]); if(ret) vars[41] = ret; } catch(e) { }
try { var ret = vars[32][1000]; if(ret) vars[48] = ret; } catch(e) { }
try { var ret = Array.prototype.pop.call(vars[43]); if(ret) vars[97] = ret; } catch(e) { }
try { var ret = RangeError(true, vars[63], vars[71]); if(ret) vars[89] = ret; } catch(e) { }
try { vars[86].source = vars[72]; } catch(e) { }
try { var ret = vars[84].apply(vars[51], vars[75]); if(ret) vars[62] = ret; } catch(e) { }
try { vars[62].options = false; } catch(e) { }
try { var ret = String.prototype.match.call(vars[91], vars[86]); if(ret) vars[39] = ret; } catch(e) { }
try { var ret = vars[17].apply(vars[55], vars[74]); if(ret) vars[21] = ret; } catch(e) { }
try { vars[33].toFixed = f0; } catch(e) { }
try { vars[84].arguments = vars[13]; } catch(e) { }
try { RegExp.prototype.compile.call(vars[49], Array(17).join(String.fromCharCode(1)) + Array(17).join(String.fromCharCode(32, 95, 113))); } catch(e) { }
try { var ret = vars[53].lastIndex; if(ret) vars[75] = ret; } catch(e) { }
try { var ret = new EvalError(arg2, Infinity, vars[65]); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = Date(true, 'a', vars[27], true, vars[50], vars[90], vars[29]); if(ret) vars[81] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[16], vars[15]); if(ret) vars[48] = ret; } catch(e) { }
try { var ret = vars[43].toExponential; if(ret) vars[24] = ret; } catch(e) { }
try { var ret = ActiveXObject(false, -1); if(ret) vars[42] = ret; } catch(e) { }
try { var ret = Array.prototype.splice.call(vars[92], vars[21], 'a'); if(ret) vars[7] = ret; } catch(e) { }
try { var ret = vars[61].call(vars[48], arg9, Infinity, 'a', vars[28], false); if(ret) vars[85] = ret; } catch(e) { }
try { var ret = EvalError(vars[93], true, vars[33]); if(ret) vars[67] = ret; } catch(e) { }
try { var ret = new vars[32](false, 1, false, vars[80], -1); if(ret) vars[10] = ret; } catch(e) { }
try { var ret = Array.prototype.sort.call(vars[36], f4); if(ret) vars[16] = ret; } catch(e) { }
try { vars[5].toLocaleString = f6; } catch(e) { }
try { vars[68] = Date; } catch(e) { }
try { var ret = vars[7].apply(vars[11], vars[57]); if(ret) vars[23] = ret; } catch(e) { }
try { vars[62].length = Infinity; } catch(e) { }
try { vars[23][1000] = true; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[96], 1000, vars[91]); if(ret) vars[40] = ret; } catch(e) { }
try { var ret = Enumerator('a'); if(ret) vars[24] = ret; } catch(e) { }
try { var ret = Date.parse(false); if(ret) vars[48] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[42], 3, false); if(ret) vars[35] = ret; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[27]); if(ret) vars[39] = ret; } catch(e) { }
try { var ret = new RegExp(Array(17).join(String.fromCharCode(114)) + Array(65537).join(String.fromCharCode(113, 94)), 'g'); if(ret) vars[35] = ret; } catch(e) { }
try { var ret = EncodeURI(Infinity); if(ret) vars[2] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[49], arg8, arg6); if(ret) vars[61] = ret; } catch(e) { }
try { var ret = Debug.write(vars[75]); if(ret) vars[39] = ret; } catch(e) { }
try { var ret = String.prototype.toLowerCase.call(vars[58]); if(ret) vars[40] = ret; } catch(e) { }
try { vars[71].source = vars[37]; } catch(e) { }
try { var ret = RegExp.$7; if(ret) vars[56] = ret; } catch(e) { }
try { var ret = ActiveXObject(true, vars[47]); if(ret) vars[61] = ret; } catch(e) { }
try { var ret = parseInt(arg3); if(ret) vars[61] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[3]); if(ret) vars[8] = ret; } catch(e) { }
try { var ret = String.prototype.indexOf.call(vars[51], vars[73], Infinity); if(ret) vars[92] = ret; } catch(e) { }
try { vars[49] = Array(1025).join(String.fromCharCode(68, 5)); } catch(e) { }
try { vars[86] = Array(65).join(String.fromCharCode(122)); } catch(e) { }
try { vars[42].toExponential = f9; } catch(e) { }
try { vars[48].length = true; } catch(e) { }
try { var ret = ActiveXObject(arg3, true); if(ret) vars[37] = ret; } catch(e) { }
try { var ret = new RegExp(); if(ret) vars[91] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[40]); if(ret) vars[86] = ret; } catch(e) { }
try { vars[39] = new Array(5); } catch(e) { }
try { var ret = Error(); if(ret) vars[32] = ret; } catch(e) { }
try { var ret = new Enumerator(0); if(ret) vars[24] = ret; } catch(e) { }
try { vars[68].lastIndex = vars[49]; } catch(e) { }
try { vars[67][1000] = 'a'; } catch(e) { }
try { var ret = Boolean.prototype.valueOf.call(vars[29]); if(ret) vars[76] = ret; } catch(e) { }
try { var ret = new vars[56](1000, vars[2], vars[94], 0, vars[4]); if(ret) vars[91] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[66] = ret; } catch(e) { }
try { var ret = RegExp.$8; if(ret) vars[18] = ret; } catch(e) { }
try { var ret = Boolean.prototype.valueOf.call(vars[53]); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = Error(vars[98]); if(ret) vars[25] = ret; } catch(e) { }
try { var ret = RegExp.lastMatch; if(ret) vars[28] = ret; } catch(e) { }
try { var ret = new vars[27].call(vars[4], 'a', vars[51], vars[28], vars[73], vars[26]); if(ret) vars[19] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[90]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[78]); if(ret) vars[86] = ret; } catch(e) { }
try { var ret = DblFromLus(4294967296); if(ret) vars[7] = ret; } catch(e) { }
try { var ret = RegExp(Array(1025).join(String.fromCharCode(98)), 'gim'); if(ret) vars[75] = ret; } catch(e) { }
//endjs
return vars[85];

}

function f0(arg1, arg2, arg3) {
runcount.f0++; if(runcount.f0>2) return;
//alert(0);
//beginjs
try { var ret = Boolean.prototype.toString.call(vars[4]); if(ret) vars[55] = ret; } catch(e) { }
try { var ret = vars[22].caller; if(ret) vars[51] = ret; } catch(e) { }
try { var ret = []; if(ret) vars[99] = ret; } catch(e) { }
try { vars[43].toPrecision = 'a'; } catch(e) { }
try { var ret = RegExp.lastParen; if(ret) vars[5] = ret; } catch(e) { }
try { var ret = new EvalError(vars[64], vars[53], 0); if(ret) vars[11] = ret; } catch(e) { }
try { var ret = vars[57].constructor; if(ret) vars[75] = ret; } catch(e) { }
try { var ret = Error.prototype.toString.call(vars[32]); if(ret) vars[25] = ret; } catch(e) { }
try { var ret = new RegExp(Array(1025).join(String.fromCharCode(38, 28, 118)), 'gig'); if(ret) vars[88] = ret; } catch(e) { }
try { var ret = vars[40].toLocaleString; if(ret) vars[69] = ret; } catch(e) { }
try { function f_inner_71() { return f9(); } vars[15] = f_inner_71; } catch(e) { }
try { vars[22].toArray = f6; } catch(e) { }
try { var ret = String.prototype.strike.call(vars[94], 'a'); if(ret) vars[44] = ret; } catch(e) { }
try { var ret = vars[86].input; if(ret) vars[58] = ret; } catch(e) { }
try { vars[82].caller = 'a'; } catch(e) { }
try { var ret = Date.prototype.getTimezoneOffset.call(vars[53]); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[18]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[37]); if(ret) vars[44] = ret; } catch(e) { }
try { var ret = Enumerator(true); if(ret) vars[89] = ret; } catch(e) { }
try { var ret = vars[32].call(vars[66], 'a', true, vars[34], false, Infinity); if(ret) vars[53] = ret; } catch(e) { }
try { var ret = escape(vars[62]); if(ret) vars[32] = ret; } catch(e) { }
try { var ret = vars[52].options; if(ret) vars[0] = ret; } catch(e) { }
try { var ret = LuHigh(vars[24]); if(ret) vars[30] = ret; } catch(e) { }
try { RegExp.prototype.test.call(vars[15], Array(65537).join(String.fromCharCode(54)) + Array(17).join(String.fromCharCode(1, 9, 53))); } catch(e) { }
try { var ret = RegExp.lastParen; if(ret) vars[65] = ret; } catch(e) { }
try { vars[1] = {}; } catch(e) { }
try { var ret = Debug.write(0, vars[54], vars[36]); if(ret) vars[94] = ret; } catch(e) { }
try { vars[17].caller = Infinity; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[96]); if(ret) vars[84] = ret; } catch(e) { }
try { vars[98] = RegExp; } catch(e) { }
try { var ret = vars[42].arguments; if(ret) vars[92] = ret; } catch(e) { }
try { var ret = Error(Infinity, 0, Infinity); if(ret) vars[77] = ret; } catch(e) { }
try { var ret = new vars[53].call(vars[73], vars[82], vars[74], true, vars[79], vars[18]); if(ret) vars[84] = ret; } catch(e) { }
try { vars[91].toLocaleString = f9; } catch(e) { }
try { vars[90] = JSON; } catch(e) { }
try { vars[99].global = vars[9]; } catch(e) { }
try { var ret = vars[29][4]; if(ret) vars[29] = ret; } catch(e) { }
try { var ret = new RangeError('a', vars[16], 'a'); if(ret) vars[60] = ret; } catch(e) { }
try { var ret = new Date(); if(ret) vars[67] = ret; } catch(e) { }
try { RegExp.prototype.exec.call(vars[46], vars[49]); } catch(e) { }
try { var ret = Array.prototype.push.call(vars[88]); if(ret) vars[22] = ret; } catch(e) { }
try { var ret = []; if(ret) vars[27] = ret; } catch(e) { }
try { var ret = vars[10].call(vars[22], vars[2], vars[48], false, arg5, 100); if(ret) vars[88] = ret; } catch(e) { }
try { var ret = String.prototype.substr.call(vars[28], vars[24]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[31], vars[91], vars[91]); if(ret) vars[29] = ret; } catch(e) { }
try { vars[79].source = 4; } catch(e) { }
try { var ret = Function.prototype.apply.call(vars[80], vars[19], vars[20]); if(ret) vars[27] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[34], 'a', arg5); if(ret) vars[97] = ret; } catch(e) { }
try { var ret = new RegExp(); if(ret) vars[53] = ret; } catch(e) { }
try { vars[75].toJSON = f5; } catch(e) { }
//endjs
return vars[68];

}

function f1(arg4, arg5, arg6) {
runcount.f1++; if(runcount.f1>2) return;
//alert(1);
//beginjs
try { var ret = Function.prototype.apply.call(vars[16], vars[11]); if(ret) vars[48] = ret; } catch(e) { }
try { vars[41].toPrecision = Infinity; } catch(e) { }
try { var ret = new Error(vars[0], vars[7], false); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = vars[48].toPrecision; if(ret) vars[89] = ret; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[26], vars[51]); if(ret) vars[44] = ret; } catch(e) { }
try { var ret = vars[11].valueOf; if(ret) vars[23] = ret; } catch(e) { }
try { var ret = String.prototype.split.call(vars[43], true); if(ret) vars[55] = ret; } catch(e) { }
try { var ret = Function.prototype.call.call(vars[49], vars[83]); if(ret) vars[60] = ret; } catch(e) { }
try { var ret = String.prototype.indexOf.call(vars[11], 'a'); if(ret) vars[35] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[46], arg6); if(ret) vars[35] = ret; } catch(e) { }
try { vars[87] = this; } catch(e) { }
try { vars[62].input = true; } catch(e) { }
try { var ret = Debug.write('a', true, vars[58]); if(ret) vars[31] = ret; } catch(e) { }
try { vars[35] = Enumerator; } catch(e) { }
try { vars[46] = Date; } catch(e) { }
try { vars[69].valueOf = f8; } catch(e) { }
try { var ret = Enumerator.prototype.moveFirst.call(vars[54]); if(ret) vars[47] = ret; } catch(e) { }
try { var ret = decodeURI(arg8); if(ret) vars[36] = ret; } catch(e) { }
try { var ret = vars[48][0]; if(ret) vars[89] = ret; } catch(e) { }
try { vars[79].toPrecision = f9; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[43], vars[38], vars[42]); if(ret) vars[73] = ret; } catch(e) { }
try { RegExp.prototype.test.call(vars[39], vars[43]); } catch(e) { }
try { var ret = []; if(ret) vars[17] = ret; } catch(e) { }
try { var ret = Array(17).join(String.fromCharCode(73, 106)) + Array(257).join(String.fromCharCode(118, 6, 62)) + Array(1025).join(String.fromCharCode(4, 66, 99)); if(ret) vars[85] = ret; } catch(e) { }
try { vars[44][3] = vars[38]; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[45], true); if(ret) vars[97] = ret; } catch(e) { }
try { vars[24] = new Array(2); } catch(e) { }
try { var ret = new Error(vars[72], vars[29], true); if(ret) vars[72] = ret; } catch(e) { }
try { var ret = Date.prototype.toUTCString.call(vars[82]); if(ret) vars[69] = ret; } catch(e) { }
try { RegExp.prototype.exec.call(vars[87], Array(65537).join(String.fromCharCode(110)) + Array(4097).join(String.fromCharCode(97, 85))); } catch(e) { }
try { vars[33][1000000] = vars[23]; } catch(e) { }
try { var ret = ReferenceError(vars[96], vars[83], vars[80]); if(ret) vars[90] = ret; } catch(e) { }
try { vars[15] = new Array(1073741824); } catch(e) { }
try { RegExp.prototype.test.call(vars[27], vars[30]); } catch(e) { }
try { var ret = encodeURIComponent(Infinity); if(ret) vars[48] = ret; } catch(e) { }
try { vars[17][4294967295] = vars[90]; } catch(e) { }
try { var ret = Date(true); if(ret) vars[97] = ret; } catch(e) { }
try { var ret = vars[45].constructor; if(ret) vars[67] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[81]); if(ret) vars[28] = ret; } catch(e) { }
try { var ret = RegExp.$6; if(ret) vars[20] = ret; } catch(e) { }
try { var ret = vars[46].lastIndex; if(ret) vars[13] = ret; } catch(e) { }
try { eval(Array(1025).join(String.fromCharCode(91, 49, 88))); } catch(e) { }
try { vars[98][536870912] = true; } catch(e) { }
try { var ret = vars[57].constructor; if(ret) vars[82] = ret; } catch(e) { }
try { vars[47].arguments = vars[35]; } catch(e) { }
try { vars[34] = new Array(-1); } catch(e) { }
try { var ret = vars[44].toFixed; if(ret) vars[75] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[32]); if(ret) vars[42] = ret; } catch(e) { }
try { var ret = Debug.writeln(true); if(ret) vars[80] = ret; } catch(e) { }
try { vars[83] = Enumerator; } catch(e) { }
//endjs
return vars[47];

}

function f2(arg7, arg8, arg9) {
runcount.f2++; if(runcount.f2>2) return;
//alert(2);
//beginjs
try { var ret = vars[46](vars[29], vars[64], vars[69], vars[63], 1073741824); if(ret) vars[53] = ret; } catch(e) { }
try { var ret = Error(vars[30]); if(ret) vars[44] = ret; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[87]); if(ret) vars[89] = ret; } catch(e) { }
try { var ret = RegExp.lastMatch; if(ret) vars[5] = ret; } catch(e) { }
try { var ret = Date(Infinity); if(ret) vars[40] = ret; } catch(e) { }
try { var ret = Enumerator.prototype.moveNext.call(vars[44]); if(ret) vars[92] = ret; } catch(e) { }
try { var ret = RegExp.lastIndex; if(ret) vars[91] = ret; } catch(e) { }
try { vars[44].valueOf = f2; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[11]); if(ret) vars[18] = ret; } catch(e) { }
try { vars[17].toLocaleString = f6; } catch(e) { }
try { var ret = vars[40].toPrecision; if(ret) vars[37] = ret; } catch(e) { }
try { vars[5] = Error; } catch(e) { }
try { var ret = Error.prototype.toString.call(vars[51]); if(ret) vars[82] = ret; } catch(e) { }
try { var ret = LuLow(true); if(ret) vars[3] = ret; } catch(e) { }
try { var ret = ReferenceError(vars[25], true, false); if(ret) vars[64] = ret; } catch(e) { }
try { var ret = new Array(vars[25], vars[36], arg5); if(ret) vars[78] = ret; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[59], false, f2); if(ret) vars[8] = ret; } catch(e) { }
try { var ret = ActiveXObject(1000000, Infinity); if(ret) vars[49] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCFullYear.call(vars[12], vars[4]); if(ret) vars[46] = ret; } catch(e) { }
try { var ret = parseFloat(vars[11]); if(ret) vars[54] = ret; } catch(e) { }
try { vars[79] = Error; } catch(e) { }
try { vars[11][2] = vars[30]; } catch(e) { }
try { var ret = LuHigh(Infinity); if(ret) vars[39] = ret; } catch(e) { }
try { RegExp.prototype.exec.call(vars[4], Array(1025).join(String.fromCharCode(100)) + Array(65537).join(String.fromCharCode(96, 11, 26))); } catch(e) { }
try { var ret = Enumerator.prototype.atEnd.call(vars[35]); if(ret) vars[62] = ret; } catch(e) { }
try { RegExp.prototype.exec.call(vars[54], Infinity); } catch(e) { }
try { var ret = String.prototype.toLowerCase.call(vars[73]); if(ret) vars[75] = ret; } catch(e) { }
try { vars[77].callee = Infinity; } catch(e) { }
try { RegExp.prototype.test.call(vars[7], false); } catch(e) { }
try { var ret = GetObject(10); if(ret) vars[50] = ret; } catch(e) { }
try { var ret = RegExp.leftContext; if(ret) vars[40] = ret; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[65], vars[9]); if(ret) vars[23] = ret; } catch(e) { }
try { var ret = arguments; if(ret) vars[95] = ret; } catch(e) { }
try { vars[6].constructor = false; } catch(e) { }
try { var ret = String.prototype.strike.call(vars[63], 0); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = vars[38].toJSON; if(ret) vars[87] = ret; } catch(e) { }
try { var ret = new Array(); if(ret) vars[27] = ret; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[94], false); if(ret) vars[35] = ret; } catch(e) { }
try { var ret = RegExp.$2; if(ret) vars[61] = ret; } catch(e) { }
try { vars[84] = f1; } catch(e) { }
try { var ret = RangeError(false, vars[45], Infinity); if(ret) vars[24] = ret; } catch(e) { }
try { var ret = RegExp.$6; if(ret) vars[12] = ret; } catch(e) { }
try { var ret = vars[17].toString; if(ret) vars[32] = ret; } catch(e) { }
try { vars[58].prototype = vars[68]; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[21], vars[89], vars[28]); if(ret) vars[68] = ret; } catch(e) { }
try { vars[27] = Boolean; } catch(e) { }
try { var ret = Enumerator(); if(ret) vars[10] = ret; } catch(e) { }
try { vars[40].toExponential = true; } catch(e) { }
try { var ret = vars[84](vars[37], vars[10], vars[91], arg8, vars[86]); if(ret) vars[97] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCFullYear.call(vars[72], true); if(ret) vars[27] = ret; } catch(e) { }
//endjs
return vars[93];

}

function f3(arg1, arg2, arg3) {
runcount.f3++; if(runcount.f3>2) return;
//alert(3);
//beginjs
try { var ret = Array.prototype.toString.call(vars[46]); if(ret) vars[58] = ret; } catch(e) { }
try { var ret = new Boolean(); if(ret) vars[25] = ret; } catch(e) { }
try { var ret = new ReferenceError(vars[48], false, Infinity); if(ret) vars[83] = ret; } catch(e) { }
try { var ret = String.prototype.strike.call(vars[42], vars[72]); if(ret) vars[52] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[63], vars[58], 'a'); if(ret) vars[84] = ret; } catch(e) { }
try { var ret = RegExp.lastMatch; if(ret) vars[41] = ret; } catch(e) { }
try { var ret = GetObject('a'); if(ret) vars[4] = ret; } catch(e) { }
try { vars[82].lastIndex = false; } catch(e) { }
try { var ret = Date.UTC(4, vars[63], 2, vars[47], vars[63], 3, vars[32]); if(ret) vars[59] = ret; } catch(e) { }
try { var ret = Error(vars[87]); if(ret) vars[86] = ret; } catch(e) { }
try { RegExp.input = vars[83]; } catch(e) { }
try { var ret = vars[85].toFixed; if(ret) vars[24] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[67], 'a'); if(ret) vars[3] = ret; } catch(e) { }
try { var ret = new Array(arg5); if(ret) vars[35] = ret; } catch(e) { }
try { var ret = String.prototype.split.call(vars[55], true, vars[92]); if(ret) vars[79] = ret; } catch(e) { }
try { var ret = RangeError(true, vars[33], true); if(ret) vars[79] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[2], Array(17).join(String.fromCharCode(70)), 'g'); } catch(e) { }
try { var ret = Function.prototype.call.call(vars[40], vars[99]); if(ret) vars[53] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[99]); if(ret) vars[68] = ret; } catch(e) { }
try { var ret = new ReferenceError(vars[64], arg2, Infinity); if(ret) vars[86] = ret; } catch(e) { }
try { var ret = Boolean(); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = RegExp.$4; if(ret) vars[79] = ret; } catch(e) { }
try { var ret = []; if(ret) vars[94] = ret; } catch(e) { }
try { var ret = Array.prototype.shift.call(vars[92]); if(ret) vars[99] = ret; } catch(e) { }
try { var ret = vars[0].toLocaleString; if(ret) vars[31] = ret; } catch(e) { }
try { var ret = vars[40].toPrecision; if(ret) vars[32] = ret; } catch(e) { }
try { vars[37] = f1; } catch(e) { }
try { var ret = Array(65537).join(String.fromCharCode(67, 90)) + Array(1025).join(String.fromCharCode(67, 95, 27)) + Array(257).join(String.fromCharCode(101)); if(ret) vars[20] = ret; } catch(e) { }
try { var ret = Error(Infinity, false, vars[41]); if(ret) vars[37] = ret; } catch(e) { }
try { var ret = Date.prototype.toUTCString.call(vars[99]); if(ret) vars[15] = ret; } catch(e) { }
try { var ret = Enumerator.prototype.atEnd.call(vars[96]); if(ret) vars[32] = ret; } catch(e) { }
try { vars[69].valueOf = f8; } catch(e) { }
try { vars[72] = JSON; } catch(e) { }
try { vars[64].toFixed = f8; } catch(e) { }
try { var ret = Date.prototype.getFullYear.call(vars[76]); if(ret) vars[10] = ret; } catch(e) { }
try { var ret = String.prototype.substr.call(vars[28], 'a', vars[93]); if(ret) vars[43] = ret; } catch(e) { }
try { var ret = new RegExp(); if(ret) vars[15] = ret; } catch(e) { }
try { var ret = String.prototype.indexOf.call(vars[36], vars[62]); if(ret) vars[78] = ret; } catch(e) { }
try { vars[29].arguments = 10; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[43], true, arg2); if(ret) vars[84] = ret; } catch(e) { }
try { var ret = Debug.write(false, 'a', Infinity); if(ret) vars[92] = ret; } catch(e) { }
try { var ret = new RangeError(vars[30], vars[52], Infinity); if(ret) vars[77] = ret; } catch(e) { }
try { vars[61].toLocaleString = f3; } catch(e) { }
try { vars[11] = Error; } catch(e) { }
try { var ret = RegExp.index; if(ret) vars[7] = ret; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[88], 'a', true); if(ret) vars[15] = ret; } catch(e) { }
try { var ret = Array.prototype.push.call(vars[71], true); if(ret) vars[38] = ret; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[10]); if(ret) vars[88] = ret; } catch(e) { }
try { vars[43][0] = vars[41]; } catch(e) { }
try { var ret = Array(false); if(ret) vars[50] = ret; } catch(e) { }
//endjs
return vars[42];

}

function f4(arg4, arg5, arg6) {
runcount.f4++; if(runcount.f4>2) return;
//alert(4);
//beginjs
try { var ret = EncodeURI(vars[89]); if(ret) vars[85] = ret; } catch(e) { }
try { var ret = Array.prototype.toString.call(vars[13]); if(ret) vars[5] = ret; } catch(e) { }
try { var ret = Array(false, Infinity, vars[11]); if(ret) vars[81] = ret; } catch(e) { }
try { var ret = new ReferenceError(0, 'a', arg8); if(ret) vars[32] = ret; } catch(e) { }
try { var ret = Enumerator.prototype.atEnd.call(vars[20]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = unescape(vars[81]); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[34], Infinity, arg7); if(ret) vars[66] = ret; } catch(e) { }
try { vars[31].toString = Infinity; } catch(e) { }
try { vars[75] = {}; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[4]); if(ret) vars[3] = ret; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[85]); if(ret) vars[70] = ret; } catch(e) { }
try { var ret = Array(Infinity, vars[2], false); if(ret) vars[94] = ret; } catch(e) { }
try { var ret = unescape(Infinity); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[92], true); if(ret) vars[26] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCHours.call(vars[38]); if(ret) vars[27] = ret; } catch(e) { }
try { vars[59].toFixed = vars[5]; } catch(e) { }
try { var ret = String.prototype.toUpperCase.call(vars[99]); if(ret) vars[74] = ret; } catch(e) { }
try { var ret = []; if(ret) vars[21] = ret; } catch(e) { }
try { var ret = vars[53].appy(vars[41], vars[11]); if(ret) vars[96] = ret; } catch(e) { }
try { var ret = new URIError(10, Infinity, false); if(ret) vars[66] = ret; } catch(e) { }
try { vars[96].toString = Infinity; } catch(e) { }
try { var ret = new RuntimeObject(); if(ret) vars[40] = ret; } catch(e) { }
try { vars[92].prototype = 'a'; } catch(e) { }
try { var ret = vars[63](vars[50], vars[69], Infinity, true, true); if(ret) vars[23] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[84], arg2, true); } catch(e) { }
try { var ret = parseFloat(1000000); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = JSON.parse(arg8); if(ret) vars[31] = ret; } catch(e) { }
try { var ret = Array(vars[50]); if(ret) vars[49] = ret; } catch(e) { }
try { var ret = Debug.writeln(vars[89], false, false); if(ret) vars[64] = ret; } catch(e) { }
try { var ret = vars[56].length; if(ret) vars[36] = ret; } catch(e) { }
try { var ret = LuLow(arg5); if(ret) vars[9] = ret; } catch(e) { }
try { var ret = new Enumerator(vars[50]); if(ret) vars[23] = ret; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[36], Infinity); if(ret) vars[45] = ret; } catch(e) { }
try { vars[83][1000000] = vars[10]; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[26], vars[67]); if(ret) vars[28] = ret; } catch(e) { }
try { vars[72] = Function; } catch(e) { }
try { var ret = vars[47].constructor; if(ret) vars[67] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[93], vars[64], 1000); if(ret) vars[40] = ret; } catch(e) { }
try { var ret = Date.prototype.toLocaleString.call(vars[82]); if(ret) vars[63] = ret; } catch(e) { }
try { var ret = Array.prototype.reverse.call(vars[34]); if(ret) vars[13] = ret; } catch(e) { }
try { vars[62].input = true; } catch(e) { }
try { var ret = vars[12].lastIndex; if(ret) vars[29] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[33] = ret; } catch(e) { }
try { var ret = new Array(vars[5]); if(ret) vars[15] = ret; } catch(e) { }
try { var ret = ActiveXObject(Infinity, vars[83]); if(ret) vars[36] = ret; } catch(e) { }
try { vars[18].toString = f0; } catch(e) { }
try { var ret = vars[75].callee; if(ret) vars[49] = ret; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[93], vars[87]); if(ret) vars[53] = ret; } catch(e) { }
try { var ret = Debug.writeln(Infinity, vars[44], vars[0]); if(ret) vars[84] = ret; } catch(e) { }
try { var ret = RegExp.$7; if(ret) vars[20] = ret; } catch(e) { }
//endjs
return vars[51];

}

function f5(arg7, arg8, arg9) {
runcount.f5++; if(runcount.f5>2) return;
//alert(5);
//beginjs
try { RegExp.prototype.exec.call(vars[76], Array(17).join(String.fromCharCode(112, 17, 27))); } catch(e) { }
try { vars[59].valueOf = f8; } catch(e) { }
try { vars[30].constructor = arg6; } catch(e) { }
try { var ret = Date.prototype.setUTCFullYear.call(vars[8], vars[54]); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = JSON.parse(vars[93]); if(ret) vars[21] = ret; } catch(e) { }
try { vars[78].callee = 1000000; } catch(e) { }
try { vars[61].valueOf = f4; } catch(e) { }
try { var ret = unescape(false); if(ret) vars[78] = ret; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[75]); if(ret) vars[66] = ret; } catch(e) { }
try { var ret = vars[88].prototype; if(ret) vars[31] = ret; } catch(e) { }
try { var ret = new URIError(vars[8], arg3, vars[90]); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = Error(); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = Date.prototype.toJSON.call(vars[47]); if(ret) vars[31] = ret; } catch(e) { }
try { var ret = vars[65].lastIndex; if(ret) vars[69] = ret; } catch(e) { }
try { var ret = Date.prototype.getTimezoneOffset.call(vars[45]); if(ret) vars[92] = ret; } catch(e) { }
try { var ret = new RuntimeObject(); if(ret) vars[68] = ret; } catch(e) { }
try { vars[54] = new Array(100); } catch(e) { }
try { var ret = new Date(Infinity); if(ret) vars[68] = ret; } catch(e) { }
try { var ret = RegExp.lastParen; if(ret) vars[54] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[65], Array(65).join(String.fromCharCode(14)) + Array(65537).join(String.fromCharCode(46, 63, 61)) + Array(1025).join(String.fromCharCode(82, 80)), 'mg'); } catch(e) { }
try { var ret = vars[17].length; if(ret) vars[45] = ret; } catch(e) { }
try { var ret = new ActiveXObject(false, vars[2]); if(ret) vars[83] = ret; } catch(e) { }
try { var ret = arg3; if(ret) vars[22] = ret; } catch(e) { }
try { var ret = vars[75].length; if(ret) vars[3] = ret; } catch(e) { }
try { var ret = Array.prototype.sort.call(vars[68]); if(ret) vars[75] = ret; } catch(e) { }
try { var ret = Date.parse(true); if(ret) vars[23] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[33]); if(ret) vars[53] = ret; } catch(e) { }
try { var ret = new Enumerator(); if(ret) vars[64] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[91] = ret; } catch(e) { }
try { vars[5].toFixed = vars[37]; } catch(e) { }
try { var ret = RegExp.$6; if(ret) vars[36] = ret; } catch(e) { }
try { var ret = vars[33].appy(vars[96], 0); if(ret) vars[5] = ret; } catch(e) { }
try { var ret = new vars[71](Infinity, 'a', false, false, vars[51]); if(ret) vars[45] = ret; } catch(e) { }
try { vars[44].options = vars[54]; } catch(e) { }
try { var ret = vars[45].toExponential; if(ret) vars[46] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[71], vars[96], 1); if(ret) vars[95] = ret; } catch(e) { }
try { vars[60][4] = vars[70]; } catch(e) { }
try { var ret = new Error(vars[63], vars[76], vars[30]); if(ret) vars[32] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[58], Array(65537).join(String.fromCharCode(28, 103)) + Array(1025).join(String.fromCharCode(91, 120, 92)) + Array(1025).join(String.fromCharCode(35, 93, 85))); } catch(e) { }
try { var ret = Array.prototype.push.call(vars[96], 5); if(ret) vars[32] = ret; } catch(e) { }
try { vars[7].lastIndex = 'a'; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[6]); if(ret) vars[76] = ret; } catch(e) { }
try { var ret = RegExp.$5; if(ret) vars[56] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[89], 'a'); if(ret) vars[62] = ret; } catch(e) { }
try { vars[80].valueOf = 4294967296; } catch(e) { }
try { vars[16].valueOf = vars[35]; } catch(e) { }
try { var ret = new vars[17](vars[53], -1, vars[88], vars[91], Infinity); if(ret) vars[16] = ret; } catch(e) { }
try { var ret = Array.prototype.slice.call(vars[3]); if(ret) vars[71] = ret; } catch(e) { }
try { var ret = Function.prototype.toString.call(vars[33]); if(ret) vars[96] = ret; } catch(e) { }
try { vars[43].lastIndex = false; } catch(e) { }
//endjs
return vars[63];

}

function f6(arg1, arg2, arg3) {
runcount.f6++; if(runcount.f6>2) return;
//alert(6);
//beginjs
try { var ret = Array.prototype.sort.call(vars[96]); if(ret) vars[9] = ret; } catch(e) { }
try { var ret = decodeURIComponent(vars[15]); if(ret) vars[34] = ret; } catch(e) { }
try { var ret = Array(vars[54], arg5, arg4); if(ret) vars[60] = ret; } catch(e) { }
try { vars[29] = Function; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[24]); if(ret) vars[14] = ret; } catch(e) { }
try { vars[49].toLocaleString = f3; } catch(e) { }
try { var ret = vars[11].toExponential; if(ret) vars[41] = ret; } catch(e) { }
try { vars[6].global = true; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[87]); if(ret) vars[94] = ret; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[64]); if(ret) vars[16] = ret; } catch(e) { }
try { var ret = GetObject(vars[31]); if(ret) vars[60] = ret; } catch(e) { }
try { vars[59] = Enumerator; } catch(e) { }
try { var ret = String.prototype.charAt.call(vars[91], vars[9]); if(ret) vars[92] = ret; } catch(e) { }
try { var ret = arg5; if(ret) vars[54] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[72], false, vars[34]); if(ret) vars[50] = ret; } catch(e) { }
try { var ret = RegExp.leftContext; if(ret) vars[76] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[69], Array(65).join(String.fromCharCode(40, 115)) + Array(17).join(String.fromCharCode(90, 106)) + Array(17).join(String.fromCharCode(112, 35))); } catch(e) { }
try { vars[47].toExponential = f9; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[44], true); if(ret) vars[65] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCHours.call(vars[83]); if(ret) vars[22] = ret; } catch(e) { }
try { var ret = RegExp(); if(ret) vars[96] = ret; } catch(e) { }
try { var ret = Array.prototype.toLocaleString.call(vars[41]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = Array(vars[98], vars[0], vars[40]); if(ret) vars[76] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[27] = ret; } catch(e) { }
try { var ret = RuntimeObject(); if(ret) vars[21] = ret; } catch(e) { }
try { vars[69].length = vars[98]; } catch(e) { }
try { var ret = Enumerator(vars[34]); if(ret) vars[82] = ret; } catch(e) { }
try { var ret = String.prototype.toLowerCase.call(vars[59]); if(ret) vars[98] = ret; } catch(e) { }
try { var ret = RegExp.$6; if(ret) vars[83] = ret; } catch(e) { }
try { var ret = Date.prototype.getTimezoneOffset.call(vars[56]); if(ret) vars[61] = ret; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[47], vars[69], f6); if(ret) vars[33] = ret; } catch(e) { }
try { var ret = RegExp.$1; if(ret) vars[45] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[69], vars[7]); if(ret) vars[19] = ret; } catch(e) { }
try { var ret = new vars[9].call(vars[65], vars[56], false, vars[17], 'a', 1000000); if(ret) vars[64] = ret; } catch(e) { }
try { vars[66] = new Array(10); } catch(e) { }
try { var ret = arguments; if(ret) vars[60] = ret; } catch(e) { }
try { var ret = Array(vars[28]); if(ret) vars[54] = ret; } catch(e) { }
try { vars[93] = {}; } catch(e) { }
try { var ret = Date(vars[89], 1000000, 3, arg7, vars[86], false, vars[27]); if(ret) vars[87] = ret; } catch(e) { }
try { var ret = Enumerator(); if(ret) vars[3] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[34], false, vars[93]); if(ret) vars[64] = ret; } catch(e) { }
try { vars[89].toExponential = 1; } catch(e) { }
try { var ret = arg1; if(ret) vars[23] = ret; } catch(e) { }
try { var ret = String.prototype.indexOf.call(vars[45], vars[48]); if(ret) vars[14] = ret; } catch(e) { }
try { vars[12] = {}; } catch(e) { }
try { var ret = LuLow(arg9); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = vars[20].appy(vars[54], vars[74]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = String.prototype.match.call(vars[5], vars[74]); if(ret) vars[4] = ret; } catch(e) { }
try { var ret = RegExp.lastMatch; if(ret) vars[42] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCFullYear.call(vars[72], vars[28], vars[0], vars[81]); if(ret) vars[27] = ret; } catch(e) { }
//endjs
return vars[88];

}

function f7(arg4, arg5, arg6) {
runcount.f7++; if(runcount.f7>2) return;
//alert(7);
//beginjs
try { var ret = vars[11].toExponential; if(ret) vars[18] = ret; } catch(e) { }
try { var ret = RegExp.input; if(ret) vars[30] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[3], Array(17).join(String.fromCharCode(27, 55)), 'g'); } catch(e) { }
try { var ret = Array.prototype.reverse.call(vars[44]); if(ret) vars[59] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[33], vars[74], 'a'); if(ret) vars[17] = ret; } catch(e) { }
try { var ret = vars[92].constructor; if(ret) vars[15] = ret; } catch(e) { }
try { vars[55].global = vars[35]; } catch(e) { }
try { var ret = URIError(100, vars[58], false); if(ret) vars[63] = ret; } catch(e) { }
try { vars[57].prototype = 100; } catch(e) { }
try { RegExp.prototype.test.call(vars[33], arg5); } catch(e) { }
try { vars[71] = {}; } catch(e) { }
try { var ret = new RegExp(); if(ret) vars[99] = ret; } catch(e) { }
try { var ret = Date.prototype.getMilliseconds.call(vars[40]); if(ret) vars[76] = ret; } catch(e) { }
try { var ret = new Error(true); if(ret) vars[6] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[90], true); if(ret) vars[92] = ret; } catch(e) { }
try { var ret = RegExp(Array(1025).join(String.fromCharCode(99, 24, 68)) + Array(4097).join(String.fromCharCode(8, 125))); if(ret) vars[23] = ret; } catch(e) { }
try { var ret = String.prototype.indexOf.call(vars[4], vars[92], 'a'); if(ret) vars[55] = ret; } catch(e) { }
try { var ret = JSON.stringify(vars[47]); if(ret) vars[65] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[87], Array(65).join(String.fromCharCode(83, 19)) + Array(4097).join(String.fromCharCode(85, 87)) + Array(17).join(String.fromCharCode(7)), 'igm'); } catch(e) { }
try { var ret = Array.prototype.shift.call(vars[38]); if(ret) vars[31] = ret; } catch(e) { }
try { var ret = vars[65].valueOf; if(ret) vars[50] = ret; } catch(e) { }
try { vars[67] = Object; } catch(e) { }
try { var ret = vars[97].constructor; if(ret) vars[13] = ret; } catch(e) { }
try { vars[94].arguments = Infinity; } catch(e) { }
try { RegExp.prototype.exec.call(vars[56], Array(17).join(String.fromCharCode(5))); } catch(e) { }
try { vars[74] = JSON; } catch(e) { }
try { vars[30] = Array(4097).join(String.fromCharCode(31)) + Array(17).join(String.fromCharCode(73, 40)) + Array(65537).join(String.fromCharCode(0, 126, 101)); } catch(e) { }
try { var ret = Boolean.prototype.toJSON.call(vars[64]); if(ret) vars[16] = ret; } catch(e) { }
try { var ret = String.prototype.toLocaleUpperCase.call(vars[6]); if(ret) vars[36] = ret; } catch(e) { }
try { var ret = Date.prototype.setUTCHours.call(vars[93], arg4); if(ret) vars[49] = ret; } catch(e) { }
try { var ret = RegExp.$4; if(ret) vars[52] = ret; } catch(e) { }
try { var ret = RegExp.lastIndex; if(ret) vars[33] = ret; } catch(e) { }
try { var ret = vars[49].toExponential; if(ret) vars[11] = ret; } catch(e) { }
try { var ret = Array.prototype.sort.call(vars[58]); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = RegExp.lastParen; if(ret) vars[59] = ret; } catch(e) { }
try { vars[7][1000] = 536870911; } catch(e) { }
try { var ret = vars[49].toPrecision; if(ret) vars[15] = ret; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[12]); if(ret) vars[23] = ret; } catch(e) { }
try { var ret = new EvalError(false, 1000, vars[3]); if(ret) vars[38] = ret; } catch(e) { }
try { var ret = new RuntimeObject(); if(ret) vars[75] = ret; } catch(e) { }
try { var ret = new Boolean(); if(ret) vars[19] = ret; } catch(e) { }
try { vars[98] = new Array(4294967295); } catch(e) { }
try { vars[15].toString = f8; } catch(e) { }
try { var ret = vars[92][-1]; if(ret) vars[52] = ret; } catch(e) { }
try { vars[25][2] = 'a'; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[2]); if(ret) vars[71] = ret; } catch(e) { }
try { vars[98].global = arg6; } catch(e) { }
try { var ret = RegExp.lastParen; if(ret) vars[50] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[31], true, false); if(ret) vars[52] = ret; } catch(e) { }
try { var ret = vars[4].foo; if(ret) vars[10] = ret; } catch(e) { }
//endjs
return vars[20];

}

function f8(arg7, arg8, arg9) {
runcount.f8++; if(runcount.f8>2) return;
//alert(8);
//beginjs
try { var ret = vars[45].length; if(ret) vars[51] = ret; } catch(e) { }
try { var ret = String.prototype.toLocaleUpperCase.call(vars[59]); if(ret) vars[91] = ret; } catch(e) { }
try { var ret = ReferenceError(vars[72], true, arg6); if(ret) vars[13] = ret; } catch(e) { }
try { var ret = vars[32].options; if(ret) vars[85] = ret; } catch(e) { }
try { var ret = vars[80].appy(vars[12], Infinity); if(ret) vars[11] = ret; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[97], vars[26]); if(ret) vars[94] = ret; } catch(e) { }
try { var ret = vars[75][1000]; if(ret) vars[59] = ret; } catch(e) { }
try { vars[29].toExponential = vars[38]; } catch(e) { }
try { var ret = vars[63][0]; if(ret) vars[49] = ret; } catch(e) { }
try { var ret = RegExp.rightContext; if(ret) vars[8] = ret; } catch(e) { }
try { var ret = Error(false, false, vars[45]); if(ret) vars[50] = ret; } catch(e) { }
try { var ret = Date(vars[82], vars[46], vars[40], 100, false, 'a', true); if(ret) vars[52] = ret; } catch(e) { }
try { var ret = Date.UTC(true, vars[76], arg1, vars[34], vars[1], vars[20], vars[37]); if(ret) vars[80] = ret; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[23], true, f9); if(ret) vars[24] = ret; } catch(e) { }
try { var ret = Array.prototype.pop.call(vars[79]); if(ret) vars[28] = ret; } catch(e) { }
try { var ret = new RangeError(vars[93], vars[55], arg3); if(ret) vars[68] = ret; } catch(e) { }
try { var ret = vars[88].length; if(ret) vars[47] = ret; } catch(e) { }
try { var ret = vars[36].toPrecision; if(ret) vars[43] = ret; } catch(e) { }
try { var ret = Function.prototype.apply.call(vars[79], vars[80]); if(ret) vars[0] = ret; } catch(e) { }
try { var ret = Array.prototype.join.call(vars[6], vars[26]); if(ret) vars[82] = ret; } catch(e) { }
try { vars[33].toJSON = vars[53]; } catch(e) { }
try { var ret = String.prototype.substr.call(vars[63], 'a', vars[11]); if(ret) vars[94] = ret; } catch(e) { }
try { var ret = ReferenceError(vars[41], vars[28], 1000); if(ret) vars[0] = ret; } catch(e) { }
try { var ret = String.prototype.charAt.call(vars[67], arg9); if(ret) vars[78] = ret; } catch(e) { }
try { var ret = vars[70].toString; if(ret) vars[80] = ret; } catch(e) { }
try { var ret = Enumerator(vars[26]); if(ret) vars[31] = ret; } catch(e) { }
try { var ret = Boolean.prototype.valueOf.call(vars[23]); if(ret) vars[86] = ret; } catch(e) { }
try { var ret = [vars[66], 1, vars[85]]; if(ret) vars[23] = ret; } catch(e) { }
try { var ret = ActiveXObject(true, 100); if(ret) vars[36] = ret; } catch(e) { }
try { var ret = vars[70].apply(vars[5], vars[22]); if(ret) vars[34] = ret; } catch(e) { }
try { var ret = RegExp.input; if(ret) vars[75] = ret; } catch(e) { }
try { vars[11].global = Infinity; } catch(e) { }
try { var ret = Function.prototype.apply.call(vars[70], vars[81], false); if(ret) vars[55] = ret; } catch(e) { }
try { var ret = Date.prototype.getFullYear.call(vars[38]); if(ret) vars[62] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[12] = ret; } catch(e) { }
try { var ret = vars[72].constructor; if(ret) vars[78] = ret; } catch(e) { }
try { var ret = String.prototype.replace.call(vars[71], vars[20], f6); if(ret) vars[46] = ret; } catch(e) { }
try { var ret = new EvalError(vars[66], vars[75], vars[46]); if(ret) vars[89] = ret; } catch(e) { }
try { var ret = RegExp.$6; if(ret) vars[91] = ret; } catch(e) { }
try { var ret = RegExp.$1; if(ret) vars[32] = ret; } catch(e) { }
try { RegExp.prototype.test.call(vars[22], Array(65537).join(String.fromCharCode(29)) + Array(1025).join(String.fromCharCode(46, 62, 104)) + Array(65).join(String.fromCharCode(61))); } catch(e) { }
try { vars[63] = Enumerator; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[38], true); if(ret) vars[76] = ret; } catch(e) { }
try { vars[38].constructor = true; } catch(e) { }
try { var ret = RegExp(Array(17).join(String.fromCharCode(18, 59)) + Array(4097).join(String.fromCharCode(82)) + Array(65).join(String.fromCharCode(32)), 'mm'); if(ret) vars[5] = ret; } catch(e) { }
try { RegExp.prototype.exec.call(vars[31], Array(4097).join(String.fromCharCode(56, 17)) + Array(257).join(String.fromCharCode(22, 28))); } catch(e) { }
try { var ret = Array(2, 5, vars[74]); if(ret) vars[55] = ret; } catch(e) { }
try { var ret = []; if(ret) vars[91] = ret; } catch(e) { }
try { vars[36] = {}; } catch(e) { }
try { vars[6] = {}; } catch(e) { }
//endjs
return vars[39];

}

function f9(arg1, arg2, arg3) {
runcount.f9++; if(runcount.f9>2) return;
//alert(9);
//beginjs
try { var ret = Debug.write(vars[77], 100, vars[61]); if(ret) vars[89] = ret; } catch(e) { }
try { var ret = EncodeURI('a'); if(ret) vars[99] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[55], true); if(ret) vars[30] = ret; } catch(e) { }
try { var ret = String.prototype.localeCompare.call(vars[89], vars[11]); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = String.prototype.concat.call(vars[0], Infinity); if(ret) vars[69] = ret; } catch(e) { }
try { RegExp.prototype.compile.call(vars[90], vars[4], 10); } catch(e) { }
try { vars[99].source = vars[13]; } catch(e) { }
try { var ret = Date.UTC(vars[79], vars[33], vars[87], true, vars[35], vars[6], vars[29]); if(ret) vars[43] = ret; } catch(e) { }
try { vars[11].source = arg7; } catch(e) { }
try { var ret = Function.prototype.apply.call(vars[40], vars[86]); if(ret) vars[57] = ret; } catch(e) { }
try { var ret = RegExp.$3; if(ret) vars[63] = ret; } catch(e) { }
try { vars[61] = {}; } catch(e) { }
try { var ret = RegExp(Array(1025).join(String.fromCharCode(20)) + Array(65537).join(String.fromCharCode(95))); if(ret) vars[26] = ret; } catch(e) { }
try { vars[89][2147483648] = vars[6]; } catch(e) { }
try { vars[78] = JSON; } catch(e) { }
try { vars[19] = f5; } catch(e) { }
try { var ret = new URIError(arg6, 1000000, vars[30]); if(ret) vars[68] = ret; } catch(e) { }
try { var ret = Object.getOwnPropertyDescriptor(vars[88], vars[14]); if(ret) vars[13] = ret; } catch(e) { }
try { var ret = Enumerator(); if(ret) vars[3] = ret; } catch(e) { }
try { vars[22] = new Array(1000); } catch(e) { }
try { var ret = RegExp.rightContext; if(ret) vars[70] = ret; } catch(e) { }
try { var ret = URIError(arg3, vars[17], arg8); if(ret) vars[88] = ret; } catch(e) { }
try { var ret = vars[48].toPrecision; if(ret) vars[97] = ret; } catch(e) { }
try { var ret = parseInt('a'); if(ret) vars[2] = ret; } catch(e) { }
try { vars[37].toJSON = f2; } catch(e) { }
try { vars[76].valueOf = false; } catch(e) { }
try { var ret = vars[42].foo; if(ret) vars[71] = ret; } catch(e) { }
try { vars[73] = Boolean; } catch(e) { }
try { var ret = Boolean.prototype.toString.call(vars[95]); if(ret) vars[49] = ret; } catch(e) { }
try { vars[45] = Error; } catch(e) { }
try { vars[43].callee = false; } catch(e) { }
try { var ret = vars[87][3]; if(ret) vars[42] = ret; } catch(e) { }
try { var ret = Date.prototype.valueOf.call(vars[51]); if(ret) vars[71] = ret; } catch(e) { }
try { vars[78].lastIndex = vars[26]; } catch(e) { }
try { var ret = parseFloat(vars[63]); if(ret) vars[48] = ret; } catch(e) { }
try { var ret = new RegExp(); if(ret) vars[59] = ret; } catch(e) { }
try { var ret = String.prototype.split.call(vars[72], 4294967295); if(ret) vars[13] = ret; } catch(e) { }
try { var ret = Array.prototype.concat.call(vars[34], vars[69]); if(ret) vars[19] = ret; } catch(e) { }
try { vars[62].length = false; } catch(e) { }
try { var ret = Array.prototype.shift.call(vars[18]); if(ret) vars[52] = ret; } catch(e) { }
try { var ret = Boolean.prototype.valueOf.call(vars[50]); if(ret) vars[74] = ret; } catch(e) { }
try { var ret = vars[54].apply(vars[84], vars[1]); if(ret) vars[75] = ret; } catch(e) { }
try { var ret = vars[99].toPrecision; if(ret) vars[38] = ret; } catch(e) { }
try { var ret = LuHigh(vars[75]); if(ret) vars[69] = ret; } catch(e) { }
try { var ret = String.prototype.lastIndexOf.call(vars[41], vars[97]); if(ret) vars[17] = ret; } catch(e) { }
try { var ret = new Array(arg3); if(ret) vars[21] = ret; } catch(e) { }
try { var ret = new vars[83].apply(vars[17], vars[81]); if(ret) vars[29] = ret; } catch(e) { }
try { var ret = String.prototype.slice.call(vars[96], arg4, vars[97]); if(ret) vars[73] = ret; } catch(e) { }
try { var ret = String.prototype.substring.call(vars[92], arg8, 1000000); if(ret) vars[59] = ret; } catch(e) { }
try { var ret = RegExp.lastMatch; if(ret) vars[21] = ret; } catch(e) { }
//endjs
return vars[23];

}

for(var i=0;i<20;i++) {
  vars[i] = new Array(10);
}
for(var i=20;i<40;i++) {
  vars[i] = 'aaaaaaaaaa';
}
for(var i=40;i<60;i++) {
  vars[i] = new Array();
}
for(var i=60;i<90;i++) {
  vars[i] = {};
}
vars[90] = f0;
vars[91] = f1;
vars[92] = f2;
vars[93] = f3;
vars[94] = f4;
vars[95] = f5;
vars[96] = f6;
vars[97] = f7;
vars[98] = f8;
vars[99] = f9;

main();


